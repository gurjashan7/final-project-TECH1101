// script.js
console.log("Welcome to Gurjashanpreet Singh's website!");

// Future enhancement example:
// Add dark/light mode toggle or interactive effects here

document.addEventListener("DOMContentLoaded", () => {
  const heroText = document.querySelector(".hero-content");
  heroText.classList.add("animated");
});
